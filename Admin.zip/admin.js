var fetch = global.nodemodule["node-fetch"];

var Adminbot_get = function Adminbot_get(type, data) {
	(async function () {
        var returntext = `|WECOM| Chào Mừng Đến BOt của ME
Admin NGuyễn THế Nam
 Link facebook fb.com/NNam13
 Zalo 0587762065 
Chúc Mn chơi Bot vui vẻ add bot ko xin ad thì BAN GROUP.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	Adminbot_get: Adminbot_get
}