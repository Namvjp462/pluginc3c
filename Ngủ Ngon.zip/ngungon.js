var fetch = global.nodemodule["node-fetch"];

var ChucNguNgon_get = function ChucNguNgon_get(type, data) {
	(async function () {
		var returntext = `Chúc cậu ngủ ngon và có những giấc mơ tuyệt vời. Một giấc ngủ ngon quên đi hết buồn phiền của ngày hôm nay để ngày mai sẽ là một ngày mới đầy may mắn và tràn ngập niềm vui nhé.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	ChucNguNgon_get: ChucNguNgon_get
}