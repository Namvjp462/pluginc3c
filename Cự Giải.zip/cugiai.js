var fetch = global.nodemodule["node-fetch"];

var CuGiai_get = function CuGiai_get(type, data) {
	(async function () {
		var returntext = `Cự Giải hay còn gọi là Bắc Giải là một cung trong Cung hoàng đạo, những người sinh vào thời gian từ 22 Tháng Sáu đến 22 Tháng Bảy (22/6-22/7) sẽ thuộc cung Cancer. Nó là một trong 4 cung Thống lĩnh và là một trong 3 cung nguyên tố nước.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	CuGiai_get: CuGiai_get
}